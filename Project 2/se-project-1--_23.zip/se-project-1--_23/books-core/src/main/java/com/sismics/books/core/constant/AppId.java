package com.sismics.books.core.constant;

/**
 * Connected applications IDs.
 *
 * @author jtremeaux
 */
public enum AppId {
    
    FACEBOOK,
}
