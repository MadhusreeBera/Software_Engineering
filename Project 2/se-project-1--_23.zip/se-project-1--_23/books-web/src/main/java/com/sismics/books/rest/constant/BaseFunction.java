package com.sismics.books.rest.constant;

/**
 * Base functions.
 *
 * @author jtremeaux 
 */
public enum BaseFunction {

    /**
     * Allows the user to use the admin fonctions.
     */
    ADMIN
}
