'use strict';

/**
 * Settings default page controller.
 */
App.controller('SettingsDefault', function() {
});