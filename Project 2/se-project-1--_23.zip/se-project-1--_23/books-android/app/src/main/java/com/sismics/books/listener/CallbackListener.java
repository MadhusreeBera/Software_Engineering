package com.sismics.books.listener;

/**
 * Simple listener.
 * 
 * @author bgamard
 */
public interface CallbackListener {
    public void onComplete();
}
