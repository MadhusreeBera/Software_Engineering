#!/bin/sh
docker build -t sismics/books .
